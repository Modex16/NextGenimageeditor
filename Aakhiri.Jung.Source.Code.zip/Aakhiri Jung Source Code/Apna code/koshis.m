for i=1:3
    print('ankit');
end